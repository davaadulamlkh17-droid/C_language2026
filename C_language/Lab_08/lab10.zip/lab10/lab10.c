//bodlogo8 
#include <stdio.h>
int main(){
    int n;
    printf("Hemjee: ");
    scanf("%d", &n);
    int a[sizeof(n)][sizeof(n)];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }
    int total = 0;
    for (int j = 0; j < n; j++)
    {
        if (a[0][j]==a[n-1][j])
        {
            printf("%d \n", a[0][j]);
            total=total+1;
        }
    } printf("Niit: %d", total);
    if (total==0)
    {
         printf ("tentsuu element baihgui");
    }
}

//bodlogo9
#include <stdio.h>
int main(){
    int a[101], n;
    printf("heden too oruulah ve: ");
    scanf("%d", &n);
    printf("Too oruulna uu: ");
    for (int i = 0; i < n; i++)
        {
            scanf("%d", &a[i]);
        }
        printf("0-eer tugssun elementuud: ");
    for (int i = 0; i < n; i++)
        {
        if (a[i]%10==0)
            {
        printf("%d ", a[i]);
            }  
        }
    return 0;
}

//bodlogo10
#include <stdio.h>
int main(){
    int n;
    printf("heden too oruulah ve: ");
    scanf("%d", &n);
    int a[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("shine massive: ");
    for (int i = 0; i < n; i++)
    {
        if (a[i]!=0)
        {
            printf("%d ", a[i]);
        }
    }
}

//bodlogo11
#include <stdio.h>
int main() {
    int n;
    printf("Too oruulna uu: ");
    scanf("%d", &n);
    int a[20], i = 0;
    while (n > 0) {
        a[i++] = n % 10;
        n /= 10;
    }
    for (int j = i - 1; j >= 0; j--) {
        printf("%d ", a[j]);
    }
    return 0;
}

//bodlogo12
#include <stdio.h>
int main() {
    int n, m;
    printf("Toonuudiig oruulna uu: ");
    scanf("%d %d", &n, &m);
    int a[20], i = 0;
    int iluu = 0;
    while (n > 0 || m > 0 || iluu > 0) {
        int sum = (n % 10) + (m % 10) + iluu;
        a[i++] = sum % 10;
        iluu = sum / 10;
        n /= 10;
        m /= 10;
    }
    for (int j = i - 1; j >= 0; j--) {
        printf("%d", a[j]);
    }
    return 0;
}

//bodlogo13

#include <stdio.h>
int main() {
    int n;
    scanf("%d", &n);
    int f[100];
    if (n == 1) {
        printf("1");
        return 0;
    }
    f[1] = 1;
    f[2] = 2;
    for (int i = 3; i <= n; i++) {
        f[i] = f[i-1] + f[i-2];
    }
    printf("%d", f[n]);
    return 0;
}

//bodlogo14
#include <stdio.h>
int main() {
    int n;
    scanf("%d", &n);
    int a[100];
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n - 1; i++) {
        int min = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[min]) {
                min = j;
            }
        }
        int temp = a[i];
        a[i] = a[min];
        a[min] = temp;
    }
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    return 0;
}